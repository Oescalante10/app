import React from 'react';
import Page from '../../../components/containers/page/Page';


const Tables = () => (
    <Page title='Mesas'>

    </Page>
)

export default Tables;
