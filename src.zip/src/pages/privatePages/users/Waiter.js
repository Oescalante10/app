import React from 'react';

const Waiter = () => {
    return (
        <div>
            
        </div>
    )
}

export default Waiter;
