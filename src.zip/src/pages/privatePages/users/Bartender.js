import React from 'react';

const Bartender = () => {
    return (
        <div>
            
        </div>
    )
}

export default Bartender;
