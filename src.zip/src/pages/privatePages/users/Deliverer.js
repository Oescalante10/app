import React from 'react';

const Deliverer = () => {
    return (
        <div>
            
        </div>
    )
}

export default Deliverer;
