import React from 'react';

const Administrator = () => {
    return (
        <div>
            
        </div>
    )
}

export default Administrator;
